#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    return 0;
}
